#' Acoustic recording of a \emph{Catherpes mexicanus} (canyon wren) song. 
#' 
#' @format One Wave object: \describe{
#'   
#'   \item{canyon_wren}{\emph{Catherpes mexicanus} recording}
#'   
#'   }
#'   
#' @usage data(canyon_wren)
#' 
"canyon_wren" 
